#ifndef NULLRADIO_H
#define NULLRADIO_H

#include "dev/radio.h"

extern const struct radio_driver nullradio_driver;

#endif /* NULLRADIO_H */
